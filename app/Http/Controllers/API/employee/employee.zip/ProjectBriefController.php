<?php

namespace App\Http\Controllers\API\employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\BriefAttachment;
use App\Models\ProjectBrief;
use Illuminate\Support\Facades\Storage;
use App\Services\OneDriveService;



class ProjectBriefController extends Controller
{
    public function index(){

        $data = ProjectBrief::latest()->with('attachments')->get();
        return response()->json($data);

    }

    public function store(Request $request)
    {
        $request->validate([
            'project_id' => 'required|exists:projects,id',
            'brief_description' => 'required|string|max:255',
            'brief_date' => 'nullable|date',
            'attachments.*' => 'nullable|file|max:10240', // each file max 10MB
        ]);

        $brief = ProjectBrief::create([
            'project_id' => $request->project_id,
            'created_by' => auth()->id(),
            'brief_description' => $request->brief_description,
            'brief_date' => $request->brief_date,
        ]);

       if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {

                $path = 'brief_attachments/' . $brief->id . '/' . uniqid() . '_' . $file->getClientOriginalName();

                // Upload to OneDrive
                app(OneDriveService::class)->upload(
                    $path,
                    file_get_contents($file->getRealPath())
                );

                BriefAttachment::create([
                    'brief_id'   => $brief->id,
                    'created_by'=> auth()->id(),
                    'file_path' => $path,
                    'file_type' => $file->getClientMimeType(),
                    'file_size' => $file->getSize(),
                    'file_name' => $file->getClientOriginalName(),
                ]);
            }
        }


        briefAddedNotification($request->project_id, "project_brief_added");

        return response()->json(['message' => 'Project Brief created successfully.', 'brief' => $brief]);
    }

    public function show($id)
    {
        $task = ProjectBrief::with(['attachments'])->findOrFail($id);
        return response()->json($task);
    }

    public function update(Request $request, $id)
    {
        $brief = ProjectBrief::findOrFail($id);

        $request->validate([
            'brief_description' => 'sometimes|required|string|max:255',
            'brief_date'        => 'nullable|date',
            'attachments.*'     => 'nullable|file|max:10240', // Optional new attachments
            'delete_attachments'=> 'nullable|array',
            'delete_attachments.*' => 'integer|exists:brief_attachments,id',
        ]);

        // Update brief fields
        $brief->update($request->only([
            'brief_description',
            'brief_date',
        ]));

        // Handle new file uploads (optional addition)
        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {

                $path = 'brief_attachments/' . $brief->id . '/' . uniqid() . '_' . $file->getClientOriginalName();

                // Upload to OneDrive
                app(OneDriveService::class)->upload(
                    $path,
                    file_get_contents($file->getRealPath())
                );

                BriefAttachment::create([
                    'brief_id'   => $brief->id,
                    'created_by' => auth()->id(),
                    'file_path'  => $path,
                    'file_type'  => $file->getClientMimeType(),
                    'file_size'  => $file->getSize(),
                    'file_name'  => $file->getClientOriginalName(),
                ]);
            }
        }

        // Handle file deletions (if any)
        if ($request->has('delete_attachments')) {
            foreach ($request->delete_attachments as $attachmentId) {

                $attachment = BriefAttachment::where('brief_id', $brief->id)
                    ->where('id', $attachmentId)
                    ->first();

                if ($attachment) {
                    // Delete from OneDrive
                    app(OneDriveService::class)->delete($attachment->file_path);

                    // Delete DB record
                    $attachment->delete();
                }
            }
        }


        return response()->json([
            'message' => 'Project Brief updated successfully.',
            'brief'   => $brief->load('attachments') // Optional: include attachments
        ]);
    }

     public function destroy($id)
    {
        $project = ProjectBrief::findOrFail($id);
        $project->delete();

        return response()->json([
            'message' => 'Project Brief deleted successfully.',
        ]);
    }
}
