<?php

namespace App\Http\Controllers\API\employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Screenshot;
use App\Models\WorkSession;
use Auth;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use Illuminate\Support\Facades\DB;
use App\Models\TrackWindow;
use App\Models\WorkingHour;
use App\Models\ActivityLog;
use Illuminate\Support\Facades\Validator;


class WorkSessionController extends Controller
{

   public function index(Request $request)
{
    try {
        $userId = Auth::id();
        
      $query = WorkSession::with('screenshots', 'taskDetail', 'userDetail', 'idleTimes')
        ->where('user_id', $userId);
    
        // Use current date if no dates provided
        $filterStartDate = $request->start_date ?? now()->toDateString();
        $filterEndDate = $request->end_date ?? $filterStartDate;
        
        // Date filters
        $query->where(function($q) use ($filterStartDate, $filterEndDate) {
            $q->whereBetween('start_date', [$filterStartDate, $filterEndDate])
              ->orWhereBetween('end_date', [$filterStartDate, $filterEndDate])
              ->orWhere(function($q2) use ($filterStartDate, $filterEndDate) {
                  $q2->where('start_date', '<', $filterStartDate)
                     ->where('end_date', '>', $filterEndDate);
              });
        });
        
        // ✅ Extra filters for task_id / project_id
        if ($request->filled('task_id')) {
            $query->where('task_id', $request->task_id);
        }
        
        if ($request->filled('project_id')) {
            $query->whereHas('taskDetail', function($q) use ($request) {
                $q->where('project_id', $request->project_id);
            });
        }



        $sessions = $query->orderBy('created_at', 'desc')->paginate(400);

        $overallTotalSeconds = 0;
        $time_strings_hr = [];

        foreach ($sessions as $session) {
            $sessionStart = Carbon::parse($session->start_date . ' ' . $session->start_time);
            
            if (is_null($session->end_time)) {
                $sessionEnd = now();
                $session->total_time = 'Running';
            } else {
                $endDate = $session->end_date ?? $session->start_date;
                $sessionEnd = Carbon::parse($endDate . ' ' . $session->end_time);
            }

            // Initialize duration for the filtered date range
            $sessionDuration = 0;
            
            // Get all dates in the filter range
            $filterDates = [];
            $currentDate = Carbon::parse($filterStartDate);
            $endDateObj = Carbon::parse($filterEndDate);
            
            while ($currentDate->lte($endDateObj)) {
                $filterDates[] = $currentDate->toDateString();
                $currentDate->addDay();
            }

            // Calculate time for each day in filter range
            foreach ($filterDates as $date) {
                $dayStart = Carbon::parse($date)->startOfDay();
                $dayEnd = Carbon::parse($date)->endOfDay();
                
                // Get overlapping period between session and this specific day
                $workStart = max($sessionStart, $dayStart);
                $workEnd = min($sessionEnd, $dayEnd);
                
                if ($workStart->lt($workEnd)) {
                    $sessionDuration += $workEnd->diffInSeconds($workStart);
                }
            }

            // Calculate adjustments for the filtered period
            $adjustmentSeconds = 0;
            $adjustments = DB::table('session_time_adjustments')
                ->where('session_id', $session->id)
                ->get();

            foreach ($adjustments as $adj) {
                if (empty($adj->start_time) || empty($adj->end_time)) {
                    continue;
                }
                
                $adjStart = Carbon::parse($adj->start_time);
                $adjEnd = Carbon::parse($adj->end_time);
                
                // Calculate adjustments day by day to respect midnight boundaries
                foreach ($filterDates as $date) {
                    $dayStart = Carbon::parse($date)->startOfDay();
                    $dayEnd = Carbon::parse($date)->endOfDay();
                    
                    $adjStartFiltered = max($adjStart, $dayStart);
                    $adjEndFiltered = min($adjEnd, $dayEnd);
                    
                    if ($adjStartFiltered->lt($adjEndFiltered)) {
                        $adjustmentSeconds += $adjEndFiltered->diffInSeconds($adjStartFiltered);
                    }
                }
            }

            $netSeconds = $sessionDuration - $adjustmentSeconds;
            
            if ($session->total_time !== 'Running') {
                $hours = floor(abs($netSeconds) / 3600);
                $minutes = floor((abs($netSeconds) % 3600) / 60);
                $session->total_time = sprintf('%dh %dm', $hours, $minutes);
                $time_strings_hr[] = $session->total_time;
            }

            $session->raw_calculation = [
                'filter_range' => [$filterStartDate, $filterEndDate],
                'session_period' => [
                    'start' => $sessionStart->format('Y-m-d H:i:s'),
                    'end' => $sessionEnd->format('Y-m-d H:i:s')
                ],
                'session_duration' => $sessionDuration,
                'adjustments' => $adjustmentSeconds,
                'net_seconds' => $netSeconds
            ];

            if ($netSeconds > 0) {
                $overallTotalSeconds += $netSeconds;
            }
        }

        // Calculate total time string
        $totalMinutes = 0;
        foreach ($time_strings_hr as $time) {
            preg_match('/(\d+)h (\d+)m/', $time, $matches);
            if (count($matches) === 3) {
                $hours = (int)$matches[1];
                $minutes = (int)$matches[2];
                $totalMinutes += ($hours * 60) + $minutes;
            }
        }
        
        $totalHours = floor($totalMinutes / 60);
        $remainingMinutes = $totalMinutes % 60;
        $totalTimeString = "{$totalHours}h {$remainingMinutes}m";

         $ids = $sessions->pluck('id')->toArray();
        $windows_activity = TrackWindow::whereIn('session_id', $ids)->get();
        
        return response()->json(
            array_merge(
                $sessions->toArray(),
                [
                    'overall_total_time' => $totalTimeString,
                    'windows_activity' => $windows_activity
                ]
            )
        );

    } catch (\Exception $e) {
        \Log::error('WorkSession Error: '.$e->getMessage());
        return response()->json([
            'error' => 'Server error',
            'message' => $e->getMessage()
        ], 500);
    }
}


    public function show($id){

        $data = WorkSession::with('screenshots','taskDetail','userDetail')
            ->findOrFail($id);

        return response()->json($data);
    }

   public function store(Request $request)
{
    $userId = Auth::id();
    
    $my_working_hours = WorkingHour::where('employee_id', $userId)->get();
    
    if ($userId == 173 || $userId == 146) {
        $now = Carbon::now()->subHours(2);
    }elseif($userId == 182){
        $now = Carbon::now()->addHours(2);
    } 
    else {
        $now = Carbon::now();
    }
    

    // 1. Check if current time falls within any of the user's working hours
    if ($my_working_hours->count() > 0) {
        $withinWorkingHours = false;
        foreach ($my_working_hours as $slot) {
            $start = Carbon::parse($slot->start_time);
            $end = Carbon::parse($slot->end_time);

            // Check if current time is within this slot
            if ($now->between($start, $end)) {
                $withinWorkingHours = true;
                break;
            }
        }

        if (!$withinWorkingHours) {
            return response()->json([
                'error' => 'You cannot start a work session outside your working hours.',
                'error_code' => "working_hours_restriction"
            ], 404);
        }
    }
    // If no working hours defined, allow starting anytime

    // 2. Check if any open session exists for this user
    $openSession = WorkSession::where('user_id', $userId)
        ->whereNull('end_time')
        ->latest('start_time')
        ->first();

    // 3. Close the previous open session (if exists)
    if ($openSession) {
        $lastScreenshot = Screenshot::where('session_id', $openSession->id)
            ->latest('created_at')
            ->first();

        if ($lastScreenshot) {
            $adjustedTime = Carbon::parse($lastScreenshot->created_at);
            $openSession->end_time = $adjustedTime;
            $openSession->end_date = $adjustedTime->toDateString();
        } else {
            $openSession->end_time = Carbon::now();
            $openSession->end_date = Carbon::now()->toDateString();
        }

        $openSession->save();
    }

    // 4. Start a new session
    $newSession = new WorkSession();
    $newSession->user_id = $userId;
    $newSession->task_id = $request->task_id;
    $newSession->memo_content = $request->memo_content;
    $newSession->start_time = $now;
    $newSession->start_date = $now->toDateString();
    $newSession->save();

    return response()->json([
        'message' => 'Work session started successfully. Previous session closed if it was open.',
        'work_session' => $newSession
    ]);
}




    public function stop(Request $request)
    {
        $userId = Auth::id();

        // If work_session_id is provided, stop that specific session.
        // This prevents stale queued stop-actions from closing a later active session.
        if ($request->filled('work_session_id')) {
            $openSession = WorkSession::where('user_id', $userId)
                ->where('id', $request->work_session_id)
                ->first();

            if (!$openSession) {
                return response()->json(['message' => 'Work session not found.'], 404);
            }

            // Already stopped — accept gracefully so the action queue can move on
            if (!is_null($openSession->end_time)) {
                return response()->json([
                    'message' => 'Work session already stopped.',
                    'work_session' => $openSession
                ]);
            }
        } else {
            // Fallback: stop the latest open session (legacy / web path)
            $openSession = WorkSession::where('user_id', $userId)
                ->whereNull('end_time')
                ->latest('start_time')
                ->first();

            if (!$openSession) {
                return response()->json([
                    'message' => 'No active work session found to stop.'
                ], 404);
            }
        }

        // Determine end time
        $now = Carbon::now();
        $sessionEndTime = $request->filled('end_time')
            ? Carbon::parse($request->end_time)
            : $now;

        $sessionEndDate = $request->filled('end_date')
            ? Carbon::parse($request->end_date)->toDateString()
            : $now->toDateString();

        // ----------------------------------------------
        // CLOSE ANY ACTIVE TRACK WINDOW FOR THIS SESSION
        // ----------------------------------------------
        $openWindow = TrackWindow::where('employee_id', $userId)
            ->where('session_id', $openSession->id)
            ->whereNull('end_time')
            ->latest('start_time')
            ->first();

        if ($openWindow) {

            // Set end_time same as WorkSession end_time
            $openWindow->end_time = $sessionEndTime;

            // Calculate duration
            $start = Carbon::parse($openWindow->start_time);
            $end   = Carbon::parse($sessionEndTime);

            $openWindow->duration_seconds = $start->diffInSeconds($end);

            $openWindow->save();
        }

        // ----------------------------------------------
        // CLOSE WORK SESSION
        // ----------------------------------------------
        $openSession->end_time = $sessionEndTime;
        $openSession->end_date = $sessionEndDate;
        $openSession->save();

        return response()->json([
            'message' => 'Work session stopped successfully.',
            'work_session' => $openSession
        ]);
    }

    public function destroy($id)
    {
        $task = WorkSession::findOrFail($id);
        $task->delete();

        return response()->json(['message' => 'Work session deleted successfully.']);
    }

    public function manualSession(Request $request)
    {

        $data = new WorkSession();
        $data->user_id = Auth::user()->id;
        $data->start_date = $request->start_date;
        $data->start_time = $request->start_time;
        $data->end_date = $request->end_date;
        $data->end_time = $request->end_time;
        $data->memo_content = $request->memo_content;
        $data->task_id = $request->task_id;
        $data->type = "Manual";
        $data->save();

        return response()->json([
            'message' => 'Manual time added successfully.',
            'work_session' => $data
        ]);

    }


   public function sessionHeartBeat(Request $request)
    {
        // ✅ Validate request
        $validator = Validator::make($request->all(), [
            'session_id' => 'required|exists:work_sessions,id',
            'type' => 'nullable|string|max:255',
    
            // Optional activity chunks (NEW SYSTEM)
            'activities' => 'nullable|array|max:500',
            'activities.*.start_time' => 'required_with:activities|date',
            'activities.*.end_time' => 'required_with:activities|date',
            'activities.*.keyboard_clicks' => 'nullable|integer',
            'activities.*.mouse_clicks' => 'nullable|integer',
            'activities.*.is_idle' => 'nullable|boolean',
            'activities.*.active_window_title' => 'nullable|string|max:255',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid data',
                'errors' => $validator->errors(),
            ], 422);
        }
    
        DB::beginTransaction();
    
        try {
            // ✅ Fetch session
            $session = WorkSession::find($request->session_id);
    
            if (!$session) {
                return response()->json([
                    'status' => false,
                    'message' => 'Session not found',
                ], 404);
            }
    
            // =====================================================
            // 🔹 HEARTBEAT UPDATE (OLD SYSTEM SAFE)
            // =====================================================
            
                $userId = Auth::user()->id;
            
                if ($userId == 173 || $userId == 146) {
                    $now = Carbon::now()->subHours(2);
                }elseif($userId == 182){
                    $now = Carbon::now()->addHours(2);
                } 
                else {
                    $now = Carbon::now();
                }
            
            $updateData = [
                'last_heartbeat' => $now,
                'last_heartbeat_type' => $request->type ?? 'Active',
            ];
    
            // Reactivate session if it was ended
            if (!is_null($session->end_date) || !is_null($session->end_time)) {
                $updateData['end_date'] = null;
                $updateData['end_time'] = null;
            }
    
            $session->update($updateData);
    
            // =====================================================
            // 🔥 ACTIVITY LOGGING (NEW SYSTEM)
            // =====================================================
            if (!empty($request->activities)) {
    
                $insertData = [];
    
                foreach ($request->activities as $activity) {
                    $insertData[] = [
                        'employee_id' => Auth::user()->id,
                        'session_id' => $session->id,
    
                        'start_time' => $activity['start_time'],
                        'end_time' => $activity['end_time'],
    
                        'keyboard_clicks' => $activity['keyboard_clicks'] ?? 0,
                        'mouse_clicks' => $activity['mouse_clicks'] ?? 0,
    
                        'is_idle' => $activity['is_idle'] ?? false,
                        'active_window_title' => $activity['active_window_title'] ?? null,
    
                        'created_at' => now(),
                        'updated_at' => now(),
                    ];
                }
    
                // 🚀 Bulk insert for performance
                ActivityLog::insert($insertData);
            }
    
            DB::commit();
    
            return response()->json([
                'status' => true,
                'message' => 'Heartbeat processed successfully',
                'data' => [
                    'session_id' => $session->id,
                    'activity_logged' => !empty($request->activities),
                    'chunks_received' => count($request->activities ?? []),
                ],
            ]);
    
        } catch (\Exception $e) {
            DB::rollBack();
    
            return response()->json([
                'status' => false,
                'message' => 'Something went wrong',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function fetchActivityLogs($id)
    {
        // ✅ Validate ID
        if (!$id || !is_numeric($id)) {
            return response()->json([
                'status' => false,
                'message' => 'Invalid session ID',
            ], 422);
        }
    
        // ✅ Fetch logs
        $logs = ActivityLog::where('session_id', $id)
            ->orderBy('start_time', 'asc')
            ->get();
    
        // ✅ Handle empty data
        if ($logs->isEmpty()) {
            return response()->json([
                'status' => true,
                'message' => 'No activity logs found',
                'data' => [],
            ]);
        }
    
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $logs
        ]);
    }


}
